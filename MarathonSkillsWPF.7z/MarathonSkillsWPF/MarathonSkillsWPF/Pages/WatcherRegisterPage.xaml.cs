﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MarathonSkillsWPF.Pages
{
    /// <summary>
    /// Логика взаимодействия для SponsorRegisterPage.xaml
    /// </summary>
    public partial class WatcherRegisterPage : Window
    {
        public WatcherRegisterPage()
        {
            InitializeComponent();
            GenderBox.ItemsSource = genders;
        }

        private void ReturnButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        List<string> genders = new List<string>() { "Мужчина", "Женщина" };

        private void AcceptButton_Click(object sender, RoutedEventArgs e)
        {
            if (Name.Text != "Имя" & Name.Text != "" & Email.Text != "Email" & Email.Text != "" & Surname.Text != "Фамилия" & Surname.Text != "" 
                & Password.Text != "" & PasswordAccept.Text != "" & GenderBox.SelectedItem != null)
            {
                MessageBox.Show("Вы зарегистрировались");
            }
            else
                MessageBox.Show("Введите свои данные");
            
        }

        
    }
}
