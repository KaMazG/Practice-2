﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace MarathonSkillsWPF.Pages
{
    
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        DispatcherTimer timer = new DispatcherTimer();
        public MainWindow()
        {
            InitializeComponent();
            DateText.Text = DateTime.Now.ToString();
            timer.Tick += new EventHandler(timerTick);
            timer.Interval = new TimeSpan(0, 0, 1);
            timer.Start();
        }
        private void timerTick(object sender, EventArgs e)
        {
            DateText.Text = DateTime.Now.ToString();
        }

        private void SponsorButton_Click(object sender, RoutedEventArgs e)
        {
            SponsorRegisterPage sponsorRegisterPage = new SponsorRegisterPage();
            sponsorRegisterPage.Show();
        }

        private void WatcherButton_Click(object sender, RoutedEventArgs e)
        {
            WatcherRegisterPage watcherRegisterPage = new WatcherRegisterPage();
            watcherRegisterPage.Show();
        }

        private void RunnerButton_Click(object sender, RoutedEventArgs e)
        {
            RunnerRegisterPage runnerRegisterPage = new RunnerRegisterPage();
            runnerRegisterPage.Show();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            LoginPage loginPage = new LoginPage();
            loginPage.Show();
        }
    }
}
