﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MarathonSkillsWPF.Pages
{
    /// <summary>
    /// Логика взаимодействия для LoginPage.xaml
    /// </summary>
    public partial class LoginPage : Window
    {
        public LoginPage()
        {
            InitializeComponent();
        }

        public class User
        {
            public string email;
            public string pass;
            public string role;
        }
        public List<User> users = new List<User>(3)
        {
            new User() { email = "user@mail.com", pass = "12345", role = "Пользователь" },
            new User() { email = "admin@mail.com", pass = "admin", role = "Администратор" },
            new User() { email = "manager@mail.com", pass = "man", role = "Координатор" },
            new User() { email = "watcher@mail.com", pass = "wat", role = "Зритель" }
        };

        private void AcceptButton_Click(object sender, RoutedEventArgs e)
        {
            UserPage up = new UserPage();
            if (Email.Text != null & PasswordText.Password != null)
            {
                for (int i = 0; i < users.Count; i++)
                {
                    if (Email.Text == users[i].email & PasswordText.Password == users[i].pass)
                    {
                        up.RoleTextBlock.Text = users[i].role;
                        up.Show();
                        break;
                    }
                    if (i == users.Count - 1 & Email.Text != users[i].email & PasswordText.Password != users[i].pass)
                        MessageBox.Show("Логин или пароль неправильные");
                }
            }
            else
                MessageBox.Show("Введите все данные");
        }
    }
}
