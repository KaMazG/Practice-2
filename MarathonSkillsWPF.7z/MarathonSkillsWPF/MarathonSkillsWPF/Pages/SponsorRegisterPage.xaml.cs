﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MarathonSkillsWPF.Pages
{
    /// <summary>
    /// Логика взаимодействия для SponsorRegisterPage.xaml
    /// </summary>
    public partial class SponsorRegisterPage : Window
    {
        public SponsorRegisterPage()
        {
            InitializeComponent();
            RunnersBox.ItemsSource = runners;
        }

        private void ReturnButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        public int donate = 50;

        List<string> runners = new List<string>() { "Иван206", "Виталик304", "Влад102", "Олег3" };

        private void DonateTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            try
            {
                if (int.Parse(DonateTextBox.Text) < 1)
                    DonateTextBox.Text = "1";
                donate = int.Parse(DonateTextBox.Text);
            }
            catch (Exception)
            {
                DonateTextBox.Text = "1";
                donate = 1;
            }
        }

        private void PlusButton_Click(object sender, RoutedEventArgs e)
        {
            donate++;
            DonateTextBox.Text = donate.ToString();
        }

        private void MinusButton_Click(object sender, RoutedEventArgs e)
        {
            if(donate > 1)
                donate--;
            DonateTextBox.Text = donate.ToString();
        }

        private void AcceptButton_Click(object sender, RoutedEventArgs e)
        {
            if (NameText.Text != "Ваше имя" & NameText.Text != "" & CardHostNameText.Text != "Имя владельца" & CardHostNameText.Text != "" & 
                CardNumber.Text != "Номер карты" & CardNumber.Text != "" & CardLimitTime.Text != "2/24" & CardLimitTime.Text != "" & CVCCode.Text != "111" & CVCCode.Text != "")
            {
                if (RunnersBox.SelectedItem != null)
                    MessageBox.Show($"Вы успешно спонсировали бегуна {RunnersBox.SelectedItem} на сумму {DonateTextBox.Text}$");
                else
                    MessageBox.Show("Выберите бегуна");
            }
            else
                MessageBox.Show("Введите свои данные");
            
        }
    }
}
